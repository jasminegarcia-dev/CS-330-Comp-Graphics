///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

// Author (Student): Jasmine Garcia
// Date: August 2025
// Course: CS-330

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <GL/glew.h>

namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";

    GLuint g_MugBodyTex = 0;
    GLuint g_MugHandleTex = 0;

    // Load 2D texture with stb_image
    GLuint LoadTexture2D(const char* filePath, bool generateMipmaps = true)
    {
        int w, h, channels;
        stbi_uc* pixels = stbi_load(filePath, &w, &h, &channels, 0);
        if (!pixels)
        {
            std::cerr << "ERROR: Failed to load texture: " << filePath << std::endl;
            return 0;
        }

        GLenum format = (channels == 1) ? GL_RED : (channels == 3) ? GL_RGB : GL_RGBA;

        GLuint texID = 0;
        glGenTextures(1, &texID);
        glBindTexture(GL_TEXTURE_2D, texID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, w, h, 0, format, GL_UNSIGNED_BYTE, pixels);
        if (generateMipmaps) glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, generateMipmaps ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        glBindTexture(GL_TEXTURE_2D, 0);
        stbi_image_free(pixels);
        return texID;
    }
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Meshes
    m_basicMeshes->LoadPlaneMesh();      // ground
    m_basicMeshes->LoadCylinderMesh();   // mug body
    m_basicMeshes->LoadTorusMesh();      // mug handle
    m_basicMeshes->LoadBoxMesh();        // table/book
    m_basicMeshes->LoadSphereMesh();     // ball/fruit
    m_basicMeshes->LoadConeMesh();       // planter

    // Textures for mug parts
    g_MugBodyTex = LoadTexture2D("shaders/textures/mug_body.jpg", true);
    g_MugHandleTex = LoadTexture2D("shaders/textures/mug_handle.jpg", true);

    if (m_pShaderManager)
    {
        // objectTexture to texture unit 0
        m_pShaderManager->setIntValue(g_TextureValueName, 0);

        // Lighting your shaders expect
        // Directional light (white key light)
        m_pShaderManager->setIntValue("directionalLight.bActive", true);
        m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.4f, -1.0f, -0.6f));
        m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.25f));
        m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.80f));
        m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.50f));

        // Colored point light (warm/orange) near/above the mug
        m_pShaderManager->setIntValue("pointLights[0].bActive", true);
        m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-2.0f, 2.0f, 1.0f));
        m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.06f, 0.03f, 0.01f));
        m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.00f, 0.55f, 0.20f));
        m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.00f, 0.55f, 0.20f));

        // Turn off any remaining point lights and spotlight
        for (int i = 1; i < 5; ++i)
            m_pShaderManager->setIntValue(("pointLights[" + std::to_string(i) + "].bActive").c_str(), false);
        m_pShaderManager->setIntValue("spotLight.bActive", false);

        // Material (used by your shader Phong terms)
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 32.0f);

        // UV scale default
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(1.0f, 1.0f));
    }
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 s, p;

    // Ground plane (lit)
    s = glm::vec3(20.0f, 1.0f, 10.0f);
    p = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(s, 0, 0, 0, p);
    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseLightingName, true);
    SetShaderColor(0.80f, 0.80f, 0.80f, 1.0f);     // slight gray, so the highlights show
    m_basicMeshes->DrawPlaneMesh();

    // Table/Book under mug (box, lit)
    s = glm::vec3(2.0f, 0.5f, 2.0f);               // width, height, depth
    p = glm::vec3(-2.0f, 0.25f, 0.0f);             // top at y = 0.5
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(0.45f, 0.30f, 0.12f, 1.0f);     // brown
    m_basicMeshes->DrawBoxMesh();

    // Mug body (textured, unlit)
    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseLightingName, false);
    s = glm::vec3(0.75f, 1.0f, 0.75f);
    p = glm::vec3(-2.0f, 1.0f, 0.0f);              // sits on the box (top at y=0.5, mug center at y=1.0)
    SetTransformations(s, 0, 0, 0, p);
    if (m_pShaderManager && g_MugBodyTex != 0) {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, g_MugBodyTex);
    }
    else {
        SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f);
    }
    m_basicMeshes->DrawCylinderMesh();

    // Mug handle (textured, unlit)
    s = glm::vec3(0.2f, 0.2f, 0.2f);
    p = glm::vec3(-1.25f, 1.0f, 0.0f);
    SetTransformations(s, 0.0f, 90.0f, 0.0f, p);
    if (m_pShaderManager && g_MugHandleTex != 0) {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, g_MugHandleTex);
    }
    else {
        SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f);
    }
    m_basicMeshes->DrawTorusMesh();

    // After textured objects, unbind texture
    glBindTexture(GL_TEXTURE_2D, 0);
    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, false);

    // Sphere (ball/fruit) (lit)
    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseLightingName, true);
    s = glm::vec3(0.25f);                          // radius
    p = glm::vec3(-0.5f, 0.25f, 1.0f);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(1.00f, 0.35f, 0.15f, 1.0f);     // orange
    m_basicMeshes->DrawSphereMesh();

    // Cone (planter) (lit)
    s = glm::vec3(0.3f, 0.6f, 0.3f);
    p = glm::vec3(-3.2f, 0.3f, -0.7f);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(0.20f, 0.55f, 0.25f, 1.0f);     // green tint
    m_basicMeshes->DrawConeMesh();
}
